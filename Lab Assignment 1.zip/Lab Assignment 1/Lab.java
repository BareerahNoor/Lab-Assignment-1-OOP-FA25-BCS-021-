public class Lab {

    
    private static int counter = 0;
    private static final String ID_PREFIX = "LAB";

    
    private String id;
    private String universityName;
    private String departmentName;
    private String sectionName;
    private String labName;
    private int totalComputers;
    private int bookedComputers;
    private Date labDate;

    
    private String generateID(){
        counter++;
        return ID_PREFIX + counter;
    }

    
    public Lab(){
        this("Unknown University");
    }

    
    public Lab(String universityName){
        this(universityName,"Unknown Department");
    }

    
    public Lab(String universityName, String departmentName){
        this(universityName,departmentName,"Unknown Section");
    }
	
	
	public Lab(String universityName, String departmentName, String sectionName){
    this(universityName, departmentName, sectionName,
         "Default Lab", 30, 0, new Date(1,1,2026));
}

    
    public Lab(String universityName,String departmentName,
               String sectionName,String labName,
               int totalComputers,int bookedComputers,Date labDate){

        this.id = generateID();
        this.universityName = universityName;
        this.departmentName = departmentName;
        this.sectionName = sectionName;
        this.labName = labName;
        this.totalComputers = totalComputers;
        this.bookedComputers = bookedComputers;
        this.labDate = new Date(labDate); 
    }

    
    public Lab(Lab l){
        this.id = generateID();
        this.universityName = l.universityName;
        this.departmentName = l.departmentName;
        this.sectionName = l.sectionName;
        this.labName = l.labName;
        this.totalComputers = l.totalComputers;
        this.bookedComputers = l.bookedComputers;
        this.labDate = new Date(l.labDate);
    }

    
    public static int getTotalLabs(){
        return counter;
    }

    
    public String getId(){ return id; }
    public int getTotalComputers(){ return totalComputers; }
    public int getBookedComputers(){ return bookedComputers; }
    public Date getLabDate(){ return labDate; }

   
    public void setTotalComputers(int total){
        if(total > 0)
            this.totalComputers = total;
    }

    public void setBookedComputers(int booked){
        if(booked >=0 && booked <= totalComputers)
            this.bookedComputers = booked;
    }

    public void setLabDate(Date d){
        this.labDate = new Date(d);
    }

    
    public void bookComputers(int count){
        if(bookedComputers + count <= totalComputers){
            bookedComputers += count;
            System.out.println(count + " computers booked.");
        }
        else{
            System.out.println("Not enough computers available.");
        }
    }

    // Cancel booking
    public void cancelBooking(int count){
        if(bookedComputers - count >= 0){
            bookedComputers -= count;
            System.out.println(count + " booking cancelled.");
        }
        else{
            System.out.println("Invalid cancellation.");
        }
    }

    public int availableComputers(){
        return totalComputers - bookedComputers;
    }

    
    public boolean equals(Lab l){
        return this.id.equals(l.id);
    }

   
    public String toString(){
        return "Lab ID: " + id +
               "\nUniversity: " + universityName +
               "\nDepartment: " + departmentName +
               "\nSection: " + sectionName +
               "\nLab Name: " + labName +
               "\nTotal Computers: " + totalComputers +
               "\nBooked Computers: " + bookedComputers +
               "\nAvailable Computers: " + availableComputers() +
               "\nDate: " + labDate +
               "\n------------------------";
    }
}
	
	