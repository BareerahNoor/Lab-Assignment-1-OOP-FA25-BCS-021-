public class LabDemo{
	public static void main(String [] ars){
		Date d1=new Date(9,5,2026);
        Lab lab1=new Lab("COMSATS University","CS","BCS-C","Programming Lab",40,10,d1);
		Lab lab2 = new Lab("COMSATS University","CS","BCS-D","OOP Lab",35,5,new Date(12,6,2026));
		Lab lab3=new Lab(lab1);
		Lab lab4 = new Lab(lab1);
		lab1.bookComputers(5);
		lab1.cancelBooking(2);
		System.out.println("Lab1 equals Lab4 : " + lab1.equals(lab4));
		System.out.println(lab1);
		System.out.println(lab2);
		System.out.println(lab3);
	    System.out.println(lab4);
		System.out.println("Total Labs created : " + Lab.getTotalLabs());
	}
}
	